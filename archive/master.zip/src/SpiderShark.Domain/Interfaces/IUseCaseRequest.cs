﻿namespace SpiderShark.Domain.Interfaces
{
    public interface IUseCaseRequest<out TUseCaseResponse> { }
}
